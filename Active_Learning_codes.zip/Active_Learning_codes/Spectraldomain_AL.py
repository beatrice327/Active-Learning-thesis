"""This implementation of the Active Learning algorithm in the spectral domain has been adapted from
Tivadar Danka and can be accessed from the link https://github.com/modAL-python/modAL"""

"""In this task, the use of ActiveLearner is demonstrated on the crop area dataset in a pool-based sampling setting."""

"""Importing libraries to be used for running the code"""
import matplotlib
from modAL.disagreement import KL_max_disagreement, vote_entropy_sampling
from sklearn.decomposition import PCA
import matplotlib as mpl
import matplotlib.pyplot as plt
matplotlib.use("TkAgg")
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from copy import deepcopy
from modAL.models import ActiveLearner, Committee
import numpy as np
plt.style.use('ggplot')

"""To ensure a reproducible result across runs, a random seed is set"""
#Random number generator
RANDOM_STATE_SEED = 123
#Function provides an input to the random number generator
np.random.seed(RANDOM_STATE_SEED)

"""The entire dataset of 350 crop samples is loaded"""
#Loading the data"
path_to_file = 'C:/Thesis_Progress/Midterm/Image_classification/Ts_crops_All.csv'
TS_all = pd.read_csv(path_to_file, encoding='utf-8')

#Selecting columns with only spectral values of the points(NDVI values) for the 12 months
data = TS_all.iloc[:, [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]]

#Convert the values to array
data_arr = data.to_numpy()

#Selecting the column with crop labels
labels = TS_all.iloc[:, 15]
print('Classes:')
print(labels.unique(), '\n')

#Changing crop label names to number identifications ranging from 0-6 since there are seven classes
new_label_names = pd.factorize(labels)[0]

#Changing the label identifications to range form 1 to 7
my_new_label_names = pd.Categorical(pd.factorize(new_label_names)[0] + 1)

#convert label number identification values to array
labels_arr = my_new_label_names.to_numpy()

#Rename variables of the spectral values(NDVI values) and crop labels
X_raw = data_arr
y_raw = labels_arr

"""To visualise the crop classes, Principle Component Analysis is applied"""

# Defining our PCA transformer and fitting it onto the dataset.
pca = PCA(n_components=2, random_state=RANDOM_STATE_SEED)
transformed_TS_all = pca.fit_transform(X=X_raw)

# Isolate the data we'll need for plotting.
x_component, y_component = transformed_TS_all[:, 0], transformed_TS_all[:, 1]

#Create a dataframe of the data
transformed_TS_Df = pd.DataFrame(data=transformed_TS_all, columns=['transformed_TS_all[:, 0]', 'transformed_TS_all[:, 1]'])

# Plot our dimensionality-reduced (via PCA) dataset.
plt.figure(figsize=(10,10))
plt.xticks(fontsize=12)
plt.yticks(fontsize=14)
plt.xlabel('Principal component 1', fontsize=15)
plt.ylabel('Principal component 2', fontsize=15)
plt.title("Crop type sample distribution in the feature space before AL ", fontsize=15)
targets = ['Alfalfa', 'Beets', 'Cereals', 'Maize', 'Onions', 'Orchard', 'Potatoes']
colors = ['r', 'g', 'k', 'b', '#8f9805', 'gold', 'm']
for target, color in zip(targets,colors):
    indicesToKeep = TS_all['Class'] == target
    plt.scatter(transformed_TS_Df.loc[indicesToKeep, 'transformed_TS_all[:, 0]']
               ,   transformed_TS_Df.loc[indicesToKeep, 'transformed_TS_all[:, 1]'], c=color, s=50, marker='+')

plt.legend(targets, prop={'size': 10})
plt.show()

"""Visualise the crop sample locations """
#Creating a variable with all crop sample spectral values and their locations(selection of columns with these values)
data_2 = TS_all.iloc[:, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]]

#Convert values to array
my_data_arr = data_2.to_numpy()

#Creating a variable with all crop sample locations only
data_arr2 = my_data_arr[:, [0, 1]]

#Create a dataframe of the locations of the samples
coords_Df = pd.DataFrame(data=data_arr2, columns=['data_arr2[:, 0]', 'data_arr2[:, 1]'])

#Plotting spatial location of of all crop samples
plt.figure(figsize=(10, 10))
plt.xticks(fontsize=12)
plt.yticks(fontsize=14)
plt.xlabel('Eastings', fontsize=20)
plt.ylabel('Northings', fontsize=20)
plt.title("Crop type sample location before AL ", fontsize=20)
targets = ['Alfalfa', 'Beets', 'Cereals', 'Maize', 'Onions', 'Orchard', 'Potatoes']
colors = ['r', 'g', 'k', 'b', '#8f9805', 'gold', 'm']

for target, color in zip(targets,colors):
    indicesToKeep = TS_all['Class'] == target
    plt.scatter(coords_Df.loc[indicesToKeep, 'data_arr2[:, 0]']
               ,   coords_Df.loc[indicesToKeep, 'data_arr2[:, 1]'], c=color, s=50, marker='+')

plt.legend(targets, prop={'size': 8})
plt.show()

"""Generate the pools.Xpool has the spectral values only and the Y pool contains the labels of the samples
A deep copy constructs a new compound object and then, recursively, inserts copies into it of the objects found 
in the original."""
X_pool = deepcopy(X_raw)
y_pool = deepcopy(y_raw)

"""To create a Committee object, two things are needed namely : a list of ActiveLearner objects and a query strategy 
function which we will define now."""

# Initializing Committee members
#Specify number of members in the committee
n_members = 2

#Create a list of the committee members
learner_list = list()

#Create a list that will store the id values for all chosen training samples
initialindex = list()

#Create a list that will store the spectral values for all chosen training samples
initialval = list()

for member_idx in range(n_members):
    # initial training data
    #Specify number of samples to train each model with initially
    n_initial = 20

    #Select 20 initial random samples(instances) random samples from Xpool for  committee member using the id
    train_idx = np.random.choice(range(X_pool.shape[0]), size=n_initial, replace=False)

    # Instance selection from pool
    X_train = X_pool[train_idx]
    y_train = y_pool[train_idx]

    #Append selected instances into the list
    initialindex.append(train_idx)

    #Append selected id spectral values(NDVI values) into the list
    initialval.append(X_train)

    # Creating a reduced copy of the data with the known instances removed.
    X_pool = np.delete(X_pool, train_idx, axis=0)
    y_pool = np.delete(y_pool, train_idx)

    # Initializing learner
    learner = ActiveLearner(
        estimator=RandomForestClassifier(),
        query_strategy=vote_entropy_sampling,
        #query_strategy=KL_max_disagreement,
        X_training=X_train, y_training=y_train
    )
    learner_list.append(learner)

# Assembling the committee
committee = Committee(learner_list=learner_list)

# Visualizing the final predictions per learner
with plt.style.context('seaborn-white'):
  plt.figure(figsize=(n_members * 7, 7))
  plt.xlabel('Principal component 1', fontsize=20)
  plt.ylabel('Principal component 2', fontsize=20)
  prediction = learner.predict(X_raw)
  is_correct = (prediction == y_raw)
  for learner_idx, learner in enumerate(committee):
    plt.subplot(1, n_members, learner_idx + 1)
    #plt.scatter(x=x_component, y=y_component, c=learner.predict(X_raw), cmap='viridis', marker='+',s=50)
    plt.scatter(x=x_component[is_correct], y=y_component[is_correct], c='g', marker='+', label='Correct')
    plt.scatter(x=x_component[~is_correct], y=y_component[~is_correct], c='r', marker='x', label='Incorrect')
    plt.title('Learner no. %d initial predictions' % (learner_idx + 1))
    plt.legend()
  plt.show()

  # Initial learner prediction score
  unqueried_score = committee.score(X_raw, y_raw)

  with plt.style.context('seaborn-white'):
      plt.figure(figsize=(7, 7))
      plt.xlabel('Principal component 1', fontsize=14)
      plt.ylabel('Principal component 2', fontsize=14)
      prediction = committee.predict(X_raw)
      is_correct = (prediction == y_raw)
      #plt.scatter(x=x_component, y=y_component, c=prediction, cmap='viridis',marker='+', s=50)
      plt.scatter(x=x_component[is_correct], y=y_component[is_correct], c='g', marker='+', label='Correct')
      plt.scatter(x=x_component[~is_correct], y=y_component[~is_correct], c='r', marker='x', label='Incorrect')
      plt.title('Committee initial predictions, accuracy = %1.3f' % unqueried_score)
      plt.legend()
      plt.show()

"""Exporting the initial training samples before AL """
#Obtaining the array of NDVI values chosen randomly per learner
merged = initialval[0][:][:]
merged2 = initialval[1][:][:]

#Conversion of the two arrays to lists
learner1_val =merged.tolist()
learner2_val =merged2.tolist()

#Creation of a new array with all initial samples of the two arrays
Initial_all = np.concatenate((learner1_val, learner2_val))

#Conversion of the array to a dataframe so as to export it to csv format
initial_val_df = pd.DataFrame(Initial_all)
print(initial_val_df)

#Exporting the samples
#initial_val_df.to_csv('C:/Thesis_Progress/Midterm/Final_trial/Today/40-initial.csv')

performance_history = [unqueried_score]

"""Update our model by pool-based sampling our “unlabeled” dataset U using informativeness measures.The Query by 
committee is used"""
# Query by committee
#Specify number of queries
n_queries = 310
#n_queries = 129

#Create a list that will store the spectral values for all chosen informative training samples
AL_samples = list()

for idx in range(n_queries):
    #Selecting the most informative sample
    query_idx, query_instance = committee.query(X_pool)
    #print(query_idx, query_instance)

    #Teach newly acquired labels for the ActiveLearner. Augment the available training data with the new samples X
    #and new labels y, then refits the estimator to this augmented training dataset.#
    committee.teach(
        X=X_pool[query_idx].reshape(1, -1),
        y=y_pool[query_idx].reshape(1, )
    )
    # Append selected informative instances(samples) into the list
    AL_samples.append(query_instance)

    # Remove queried instance from pool
    X_pool = np.delete(X_pool, query_idx, axis=0)
    y_pool = np.delete(y_pool, query_idx)

    # Calculate and report our model's accuracy.
    model_accuracy = committee.score(X_raw, y_raw)
    print('Accuracy after query {n}: {acc:0.4f}'.format(n=idx + 1, acc=model_accuracy))

    # Save our model's performance for plotting.
    performance_history.append(model_accuracy)

# visualizing the final predictions per learner
print()
with plt.style.context('seaborn-white'):
    plt.figure(figsize=(n_members*7, 7))
    prediction = learner.predict(X_raw)
    is_correct = (prediction == y_raw)
    for learner_idx, learner in enumerate(committee):
        plt.subplot(1, n_members, learner_idx + 1)
        #plt.scatter(x=x_component, y=y_component, c=learner.predict(X_raw), cmap='viridis', s=50)
        plt.scatter(x=x_component[is_correct], y=y_component[is_correct], c='g', marker='+', label='Correct')
        plt.scatter(x=x_component[~is_correct], y=y_component[~is_correct], c='r', marker='x', label='Incorrect')
        plt.title('Learner no. %d predictions after %d queries' % (learner_idx + 1, n_queries))
        plt.legend()
    plt.show()

# Visualizing the Committee's predictions
with plt.style.context('seaborn-white'):
    plt.figure(figsize=(7, 7))
    prediction = committee.predict(X_raw)
    is_correct = (prediction == y_raw)
    #plt.scatter(x=x_component, y=y_component, c=prediction, cmap='viridis', s=50)
    plt.scatter(x=x_component[is_correct], y=y_component[is_correct], c='g', marker='+', label='Correct')
    plt.scatter(x=x_component[~is_correct], y=y_component[~is_correct], c='r', marker='x', label='Incorrect')
    plt.title('Committee predictions after %d queries, accuracy = %1.3f'
              % (n_queries, committee.score(X_raw, y_raw)))
    plt.legend()
    plt.show()

# Plot our performance over time.
fig, ax = plt.subplots(figsize=(8.5, 6), dpi=130)

ax.plot(performance_history)
ax.scatter(range(len(performance_history)), performance_history, s=13)

ax.xaxis.set_major_locator(mpl.ticker.MaxNLocator(nbins=5, integer=True))
ax.yaxis.set_major_locator(mpl.ticker.MaxNLocator(nbins=10))
ax.yaxis.set_major_formatter(mpl.ticker.PercentFormatter(xmax=1))

ax.set_ylim(bottom=0, top=1)
ax.grid(True)

ax.set_title('Incremental classification accuracy')
ax.set_xlabel('Query iteration')
ax.set_ylabel('Classification Accuracy')
plt.show()

"""Exporting the choosen informative training samples after AL """
#Convert to array
AL_samples_arr = np.array(AL_samples)
print(AL_samples_arr)
print(AL_samples_arr.shape)

#Convert array from 3D to 2D
#new_arr = AL_samples_arr.reshape((AL_samples_arr.shape[0]*AL_samples_arr.shape[1]), AL_samples_arr.shape[2])
new_arr = AL_samples_arr.reshape(AL_samples_arr.shape[0], (AL_samples_arr.shape[1]*AL_samples_arr.shape[2]))
print(new_arr)
print(new_arr.shape)

#Conversion of the array to a dataframe so as to export it to csv format
AL_samples_df = pd.DataFrame(new_arr)
print(AL_samples_df)

#Exporting the chosen informative training samples
#AL_samples_df.to_csv('C:/Thesis_Progress/Midterm/Final_trial/Spectral_AL.csv')

